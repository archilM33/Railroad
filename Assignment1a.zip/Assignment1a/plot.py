"""
plot.py  --  generate every figure required by Assignment 1(a).

Sweeps the rigid two-point contact solver over the lateral displacement range,
follows the smooth single-point tread branch (dropping the discontinuous jump
that marks flange-contact onset), and writes publication-style PNGs.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from geometry import build_rail, build_wheel
from solver import WheelRail

plt.rcParams.update({
    "font.size": 10, "axes.grid": True, "grid.linestyle": ":",
    "grid.alpha": 0.6, "figure.dpi": 120, "axes.titlesize": 10,
    "lines.linewidth": 1.6,
})
CR, CL = "#c0392b", "#2471a3"      # right / left colours
OUT = "."


def sweep(wr, umax=9.5, n=97):
    """Solve across u_y, keep the continuous tread branch only."""
    uys = np.linspace(-umax, umax, n)
    rows, prev_y = [], None
    for uy in uys:
        d = wr.solve(float(uy))
        if prev_y is not None and abs(d['yRc'] - prev_y) > 1.5:
            d['flange'] = True          # jump = flange-contact onset
        prev_y = d['yRc']
        rows.append(d)
    keys = rows[0].keys()
    data = {k: np.array([r.get(k, np.nan) for r in rows], float) for k in keys}
    data['uy'] = uys
    return data


def _twin(ax, u, yr, yl, ylab, title, deg=False, scale=1.0):
    fr = np.degrees if deg else (lambda x: x * scale)
    ax.plot(u, fr(yr), color=CR, label="right")
    ax.plot(u, fr(yl), color=CL, label="left")
    ax.set_xlabel(r"$u_y$  [mm]"); ax.set_ylabel(ylab); ax.set_title(title)
    ax.axvline(0, color="k", lw=0.6, alpha=0.4)
    ax.legend(fontsize=8, loc="best")


# ---------------------------------------------------------------- profiles
def fig_profiles(wr):
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
    yr, zr = build_rail()
    yw, zw = build_wheel(R_tread=500.0, t_band=(-16, 22), t_throat=9.0)
    ax[0].plot(yr, zr, color="#34495e")
    ax[0].set_title("Rail head 60E1 / UIC60  (crown R300-R80-R13, cant 1:20)")
    ax[0].set_aspect("equal"); ax[0].set_xlabel("lateral [mm]"); ax[0].set_ylabel("height [mm]")
    ax[1].plot(yw, zw, color="#8e44ad")
    ax[1].set_title("Indian Standard wheel  (1:20 tread + throat + 1:2.5 flange)")
    ax[1].set_aspect("equal"); ax[1].set_xlabel("lateral $t$ [mm]"); ax[1].set_ylabel("height [mm]")
    ax[1].axvline(0, color="k", lw=0.6, ls="--", alpha=0.5)
    ax[1].text(0.3, ax[1].get_ylim()[0]*0.9, "taping\nline", fontsize=7)
    fig.tight_layout(); fig.savefig(f"{OUT}/fig_profiles.png"); plt.close(fig)


# ----------------------------------------------- right-contact close-up config
def fig_config(wr):
    """Close-up of the right wheel/rail contact: tread (u_y=0) vs flange."""
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.6))
    yw = np.linspace(wr.win_lo - 6, wr.win_hi + 6, 3000)
    yr = np.linspace(wr.win_lo - 6, wr.win_hi + 6, 3000)
    cases = ((ax[0], 0.0, "Initial: tread contact  ($u_y = 0$)"),
             (ax[1], 10.0, "Final: flange contact  ($u_y \\approx +10$ mm)"))
    for a, uy, tag in cases:
        d = wr.solve(uy)
        uz, phi = d['uz'], d['phi']
        zwR = wr.wheelR_nom.z(yw - uy) + uz - phi * yw     # rolled + shifted wheel
        a.plot(yr, wr.railR.z(yr), color="#34495e", lw=2, label="rail 60E1")
        a.plot(yw, zwR, color=CR, lw=2, label="wheel")
        yc = d['yRc']
        a.plot(yc, wr.railR.z(yc), 'o', color="k", ms=7, zorder=6, label="contact")
        a.set_title(tag); a.set_xlabel("track lateral $y$ [mm]")
        a.set_ylabel("height $z$ [mm]"); a.set_aspect("equal")
        a.set_xlim(wr.Y0 - 34, wr.Y0 + 26)
        a.set_ylim(-32, 6); a.legend(fontsize=8, loc="lower left")
    fig.suptitle("Right wheel–rail contact configuration  (flange faces track centre, $-y$)",
                 y=1.00, fontsize=12)
    fig.tight_layout(); fig.savefig(f"{OUT}/fig_config.png", bbox_inches="tight"); plt.close(fig)


# ------------------------------------------------- 6-panel assignment figure
def fig_main(D):
    u = D['uy']
    fig, ax = plt.subplots(2, 3, figsize=(13, 7.5))
    ax[0, 0].plot(u, D['phi'] * 1e3, color="#16a085")
    ax[0, 0].set_xlabel(r"$u_y$ [mm]"); ax[0, 0].set_ylabel(r"$\phi$ [mrad]")
    ax[0, 0].set_title(r"Roll angle $\phi$"); ax[0, 0].axhline(0, color="k", lw=0.5, alpha=0.4)
    ax[0, 1].plot(u, D['uz'], color="#e67e22")
    ax[0, 1].set_xlabel(r"$u_y$ [mm]"); ax[0, 1].set_ylabel(r"$u_z$ [mm]")
    ax[0, 1].set_title(r"Vertical displacement $u_z$")
    _twin(ax[0, 2], u, D['eta_rr'], D['eta_rl'], r"$\eta_r$ [mm]", r"Rail contact lateral $\eta_r$")
    _twin(ax[1, 0], u, D['eta_wr'], D['eta_wl'], r"$\eta_w$ [mm]", r"Wheel contact lateral $\eta_w$")
    _twin(ax[1, 1], u, D['zeta_rr'], D['zeta_rl'], r"$\zeta_r$ [mm]", r"Rail contact height $\zeta_r$")
    _twin(ax[1, 2], u, D['zeta_wr'], D['zeta_wl'], r"$\zeta_w$ [mm]", r"Wheel contact height $\zeta_w$")
    fig.suptitle("Contact kinematics vs lateral displacement  (right = red, left = blue)",
                 y=1.01, fontsize=12)
    fig.tight_layout(); fig.savefig(f"{OUT}/fig_main.png", bbox_inches="tight"); plt.close(fig)


# ---------------------------------------------------- lecture-5 solution panel
def fig_l5(D):
    u = D['uy']
    fig, ax = plt.subplots(2, 2, figsize=(11, 8))
    _twin(ax[0, 0], u, D['r_r'], D['r_l'], r"$r$ [mm]", "Rolling radius $r$")
    _twin(ax[0, 1], u, D['delta_r'], D['delta_l'], r"$\delta$ [deg]",
          "Contact angle $\\delta$", deg=True)
    _twin(ax[1, 0], u, D['Rr_r'], D['Rr_l'], r"$R_r$ [mm]", "Rail curvature radius $R_r$")
    # Rw can be very large (near-conical band) -> clip and annotate
    Rwr = np.clip(D['Rw_r'], 0, 2000); Rwl = np.clip(D['Rw_l'], 0, 2000)
    ax[1, 1].plot(u, Rwr, color=CR, label="right")
    ax[1, 1].plot(u, Rwl, color=CL, label="left")
    ax[1, 1].set_xlabel(r"$u_y$ [mm]"); ax[1, 1].set_ylabel(r"$R_w$ [mm]  (clipped @2000)")
    ax[1, 1].set_title("Wheel curvature radius $R_w$  (large on tread band)")
    ax[1, 1].legend(fontsize=8)
    fig.suptitle("Lecture-5 solution quantities vs lateral displacement", y=1.01, fontsize=12)
    fig.tight_layout(); fig.savefig(f"{OUT}/fig_lecture5.png", bbox_inches="tight"); plt.close(fig)


# --------------------------------------------------------- difference / conicity
def fig_diff(D, wr):
    u = D['uy']
    dR = D['r_r'] - D['r_l']
    dd = np.degrees(D['delta_r'] - D['delta_l'])
    # central conicity slope
    m = np.abs(u) <= 3
    lam = 0.5 * np.polyfit(u[m], dR[m], 1)[0]
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
    ax[0].plot(u, dR, color="#2c3e50")
    ax[0].plot(u, 2 * lam * u, "--", color="#c0392b",
               label=fr"linear fit  $\lambda_0={lam:.4f}$")
    ax[0].set_xlabel(r"$u_y$ [mm]"); ax[0].set_ylabel(r"$r_r-r_l$ [mm]")
    ax[0].set_title("Rolling-radius difference"); ax[0].legend(fontsize=8)
    ax[0].axhline(0, color="k", lw=0.5, alpha=0.4); ax[0].axvline(0, color="k", lw=0.5, alpha=0.4)
    ax[1].plot(u, dd, color="#2c3e50")
    ax[1].set_xlabel(r"$u_y$ [mm]"); ax[1].set_ylabel(r"$\delta_r-\delta_l$ [deg]")
    ax[1].set_title("Contact-angle difference")
    ax[1].axhline(0, color="k", lw=0.5, alpha=0.4); ax[1].axvline(0, color="k", lw=0.5, alpha=0.4)
    fig.tight_layout(); fig.savefig(f"{OUT}/fig_difference.png", bbox_inches="tight"); plt.close(fig)
    return lam


if __name__ == "__main__":
    wr = WheelRail()
    D = sweep(wr)
    fig_profiles(wr)
    fig_config(wr)
    fig_main(D)
    fig_l5(D)
    lam = fig_diff(D, wr)
    lam_cone = 1.0 / 20.0
    print("l = %.2f mm   r0 = %.1f mm   delta0 = %.3f deg" %
          (wr.l, wr.r0, np.degrees(wr.delta0)))
    print("lambda0 (numeric) = %.4f   |   pure 1:20 cone = %.4f" % (lam, lam_cone))
    print("figures written.")
