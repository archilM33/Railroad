"""
solver.py
Rigid two-point wheel-rail contact kinematics for a symmetric wheelset.

Method
------
Track frame: y lateral (+ right), z up.  The right rail is fixed at +Y0,
the left rail (mirror) at -Y0.  For a lateral displacement u_y the rigid
wheelset descends (u_z) and rolls (phi) until BOTH wheels touch their rails.

For a trial (u_z, phi) the vertical gap on each side is
        gap(y) = z_wheel(y; u_y,u_z,phi) - z_rail(y)
with the roll contribution  z += -phi*y  (roll about the track centre).
The contact point is the argmin of the gap; requiring min-gap = 0 on both
sides gives two equations for (u_z, phi), solved by Newton iteration.

From the resulting contact points every quantity in eqns (2)-(11) of the
lecture is extracted as a function of u_y:
   phi, u_z, eta_{wr,wl,rr,rl}, zeta_{wr,wl,rr,rl}, delta_{wr,wl,rr,rl},
   rolling radii r_r,r_l and profile radii of curvature R_w, R_r.
"""

import numpy as np
from scipy.interpolate import CubicSpline
from scipy.ndimage import gaussian_filter1d
from geometry import build_rail, build_wheel

MM = 1.0


class Surface:
    """A single-valued profile z = f(y) on [ymin,ymax] with slope & curvature.

    smooth_mm : optional Gaussian smoothing length [mm].  The profile is
    resampled onto a uniform grid and lightly smoothed so that the curvature
    (built from piecewise-constant arcs) varies continuously; this makes the
    contact point migrate smoothly instead of hopping between arc segments.
    """
    def __init__(self, y, z, smooth_mm=0.0):
        idx = np.argsort(y)
        y, z = y[idx], z[idx]
        # remove duplicate y (keep lowest z = running surface)
        yu, inv = np.unique(np.round(y, 6), return_inverse=True)
        zu = np.full(yu.shape, np.inf)
        for i, k in enumerate(inv):
            zu[k] = min(zu[k], z[i])
        if smooth_mm and smooth_mm > 0:
            # resample to a fine uniform grid, then Gaussian-smooth
            n = 4000
            yg = np.linspace(yu[0], yu[-1], n)
            zg = np.interp(yg, yu, zu)
            dy = yg[1] - yg[0]
            sigma = smooth_mm / dy
            zg = gaussian_filter1d(zg, sigma=sigma, mode='nearest')
            yu, zu = yg, zg
        self.spl = CubicSpline(yu, zu, extrapolate=False)
        self.ymin, self.ymax = yu[0], yu[-1]

    def z(self, y):
        return self.spl(y)

    def dz(self, y):
        return self.spl(y, 1)

    def d2z(self, y):
        return self.spl(y, 2)


class WheelRail:
    def __init__(self, Y0=792.5, r0=420.0, cant=1.0 / 20.0, R_tread=500.0,
                 smooth_mm=0.8):
        # (R_tread=500 mm running-band radius + 0.8 mm profile smoothing give a
        #  smooth single-point tread regime for |u_y| <= ~9.5 mm, with flange
        #  contact onset just beyond; effective conicity lambda0 ~ 0.061.)
        """
        Y0   : nominal lateral position of each rail crown apex region [mm]
               (~ half the contact-circle spacing)
        r0   : nominal rolling radius [mm]
        cant : rail installation inclination (1:20 IR)
        smooth_mm : profile-smoothing length [mm]; blends the piecewise arcs so
               curvature (and hence the contact angle) varies continuously.
        """
        self.Y0 = Y0
        self.r0 = r0
        self.smooth_mm = smooth_mm
        self.tread_slope = np.arctan(1.0 / 20.0)

        # --- right rail (fixed); shift so crown apex sits at +Y0 ---
        yr, zr = build_rail(cant=cant, y_center=0.0)
        yr = yr - yr[np.argmax(zr)] + Y0       # apex -> +Y0
        self.railR = Surface(yr, zr, smooth_mm=smooth_mm)
        self.railL = Surface(-yr, zr, smooth_mm=smooth_mm)   # mirror

        # --- right wheel ---
        self.slope_limit = 0.30          # contact valid until slope ~16.7 deg
        yw0, zw0 = build_wheel(y_center=0.0, R_tread=R_tread,
                               t_band=(-16.0, 22.0), t_throat=9.0)
        self._ywheel_raw = yw0
        self._zwheel_raw = zw0
        self._place_wheel()

        # generous rail search window; contact is kept on the tread band by
        # masking the wheel throat/flange (the separate flange-contact regime).
        self.win_lo = self.Y0 - 40.0
        self.win_hi = self.Y0 + 44.0
        self._central_contact()

    # ---------------------------------------------------------------
    def _place_wheel(self):
        """
        Place the wheel laterally so its straight tread contacts the crown:
        the tangency point is where the rail-crown slope equals the tread cone
        slope (+1/20) on the gauge side of the apex.  Setting the wheel tread
        line (t=0) at that rail point makes the central contact sit on the tread
        (rolling radius ~ r0).  Flange faces the track centre.
        """
        target = np.tan(self.tread_slope)
        # rail point (gauge side of apex) where dz/dy = +tan(tread_slope)
        ys = np.linspace(self.Y0 - 34, self.Y0 + 2, 4000)
        yc_star = ys[np.nanargmin(np.abs(self.railR.dz(ys) - target))]
        # wheel-frame point where the running-band slope = +tan(tread_slope)
        raw = Surface(self._ywheel_raw, self._zwheel_raw)
        ts = np.linspace(raw.ymin + 1, min(raw.ymax - 1, 20), 4000)
        t_nom = ts[np.nanargmin(np.abs(raw.dz(ts) - target))]
        self.wheel_shift = yc_star - t_nom          # align nominal points
        yw = self._ywheel_raw + self.wheel_shift
        zw = self._zwheel_raw.copy()
        self.wheelR_nom = Surface(yw, zw, smooth_mm=self.smooth_mm)
        self.wheelL_nom = Surface(-yw, zw, smooth_mm=self.smooth_mm)

    # ---------------------------------------------------------------
    def _wheel_z(self, side, y, uy, uz, phi):
        """z of the wheel running surface in the track frame."""
        if side == 'R':
            s = self.wheelR_nom
            zc = s.z(y - uy)            # lateral shift by u_y
        else:
            s = self.wheelL_nom
            zc = s.z(y - uy)
        return zc + uz - phi * y        # vertical + roll (about track centre)

    def _rail_z(self, side, y):
        return (self.railR if side == 'R' else self.railL).z(y)

    def _gap_min(self, side, uy, uz, phi, ygrid):
        zw = self._wheel_z(side, ygrid, uy, uz, phi)
        zr = self._rail_z(side, ygrid)
        gap = zw - zr
        gap = np.where(np.isfinite(gap), gap, np.inf)
        # single-point tread contact is valid until the contact reaches the
        # steep flange face; mask points whose wheel slope exceeds the limit.
        if side == 'R':
            sw = self.wheelR_nom.dz(ygrid - uy)
        else:
            sw = self.wheelL_nom.dz(ygrid - uy)
        gap = np.where(np.abs(sw) <= self.slope_limit, gap, np.inf)
        k = int(np.nanargmin(gap))
        return gap[k], ygrid[k]

    # ---------------------------------------------------------------
    def solve(self, uy, uz0=0.0, phi0=0.0):
        """Solve (u_z, phi) so both wheels touch.  Return dict of contact data."""
        # overlap grids for each side (fine), restricted to the tread band/crown
        yR = np.linspace(self.win_lo, self.win_hi, 5000)
        yL = -yR[::-1]
        uz, phi = uz0, phi0
        for _ in range(60):
            gR, yRc = self._gap_min('R', uy, uz, phi, yR)
            gL, yLc = self._gap_min('L', uy, uz, phi, yL)
            # residuals: both min gaps -> 0
            F = np.array([gR, gL])
            if np.max(np.abs(F)) < 1e-9:
                break
            # Jacobian wrt (uz, phi):  d gap/d uz = 1 ; d gap/d phi = -y_contact
            J = np.array([[1.0, -yRc],
                          [1.0, -yLc]])
            d = np.linalg.solve(J, -F)
            # damping for stability
            uz += d[0]
            phi += d[1]
        # refine contact points to sub-grid via local parabola on the gap
        yRc = self._refine('R', uy, uz, phi, yRc)
        yLc = self._refine('L', uy, uz, phi, yLc)
        return self._extract(uy, uz, phi, yRc, yLc)

    def _refine(self, side, uy, uz, phi, yc, h=0.05, iters=40):
        """Newton on d(gap)/dy = 0 to locate the tangency point precisely."""
        y = yc
        for _ in range(iters):
            if side == 'R':
                s = self.wheelR_nom
                dw = s.dz(y - uy) - phi
                d2w = s.d2z(y - uy)
            else:
                s = self.wheelL_nom
                dw = s.dz(y - uy) - phi
                d2w = s.d2z(y - uy)
            rail = self.railR if side == 'R' else self.railL
            dr = rail.dz(y)
            d2r = rail.d2z(y)
            g1 = dw - dr           # d gap/dy
            g2 = d2w - d2r         # d2 gap/dy2
            if not np.isfinite(g1) or not np.isfinite(g2) or abs(g2) < 1e-12:
                break
            step = -g1 / g2
            step = np.clip(step, -2.0, 2.0)
            y += step
            if abs(step) < 1e-10:
                break
        return y

    # ---------------------------------------------------------------
    def _extract(self, uy, uz, phi, yRc, yLc):
        r0 = self.r0
        out = {'uy': uy, 'uz': uz, 'phi': phi, 'yRc': yRc, 'yLc': yLc}
        # flange-contact onset: contact has climbed to the slope limit
        sR = abs(self.wheelR_nom.dz(yRc - uy))
        sL = abs(self.wheelL_nom.dz(yLc - uy))
        out['flange'] = (sR >= 0.98 * self.slope_limit) or (sL >= 0.98 * self.slope_limit)

        for side, yc, sign in (('R', yRc, +1), ('L', yLc, -1)):
            wheel = self.wheelR_nom if side == 'R' else self.wheelL_nom
            rail = self.railR if side == 'R' else self.railL
            tw = yc - uy                       # wheel-frame lateral of contact
            dw = wheel.dz(tw)                  # signed wheel slope (track frame)
            dr = rail.dz(yc)                   # signed rail slope (track frame)
            # Contact angle = angle of the contact normal from the vertical.
            # Physically it is a magnitude (both rails ~+2.86 deg at u_y=0);
            # store it as such so delta_r - delta_l = 0 on centre and grows as
            # the wheelset shifts.  Signed slopes are kept for the tangency check.
            delta_w = np.arctan(abs(dw))
            delta_r = np.arctan(abs(dr))
            # heights (running surfaces) at contact
            zw = wheel.z(tw)
            zr = rail.z(yc)
            # rolling radius: contact height below tread-line -> larger radius
            #   tread-line height in wheel frame is ~0 at t=0; lower zw -> +radius
            rr = r0 - zw                       # zw negative on flange -> rr>r0
            # radius of curvature
            Rw = self._Rc(wheel, tw)
            Rr = self._Rc(rail, yc)
            tag = side.lower()
            out[f'eta_w{tag}'] = tw - self.wheel0[side]   # re-origin at central
            out[f'eta_r{tag}'] = yc - self.rail0[side]
            out[f'zeta_w{tag}'] = -(zw - self.zw0[side])  # down-positive, re-origin
            out[f'zeta_r{tag}'] = -(zr - self.zr0[side])
            out[f'delta_w{tag}'] = delta_w
            out[f'delta_r{tag}'] = delta_r
            out[f'delta_{tag}'] = delta_r      # contact-plane angle
            out[f'slopew_{tag}'] = dw          # signed slopes (tangency check)
            out[f'sloper_{tag}'] = dr
            out[f'r_{tag}'] = rr
            out[f'Rw_{tag}'] = Rw
            out[f'Rr_{tag}'] = Rr
        return out

    @staticmethod
    def _Rc(surf, y):
        d1 = surf.dz(y)
        d2 = surf.d2z(y)
        if not np.isfinite(d2) or abs(d2) < 1e-9:
            return np.inf
        return (1.0 + d1 * d1) ** 1.5 / abs(d2)

    # ---------------------------------------------------------------
    def _central_contact(self):
        """Solve u_y=0 contact, store origins for re-referencing all data."""
        # temporary origins = 0 so _extract works
        self.wheel0 = {'R': 0.0, 'L': 0.0}
        self.rail0 = {'R': 0.0, 'L': 0.0}
        self.zw0 = {'R': 0.0, 'L': 0.0}
        self.zr0 = {'R': 0.0, 'L': 0.0}
        yR = np.linspace(self.win_lo, self.win_hi, 7000)
        yL = -yR[::-1]
        uz, phi = 0.0, 0.0
        for _ in range(80):
            gR, yRc = self._gap_min('R', 0.0, uz, phi, yR)
            gL, yLc = self._gap_min('L', 0.0, uz, phi, yL)
            F = np.array([gR, gL])
            if np.max(np.abs(F)) < 1e-10:
                break
            J = np.array([[1.0, -yRc], [1.0, -yLc]])
            uz, phi = np.array([uz, phi]) + np.linalg.solve(J, -F)
        yRc = self._refine('R', 0.0, uz, phi, yRc)
        yLc = self._refine('L', 0.0, uz, phi, yLc)
        self.central = {'uz': uz, 'phi': phi, 'yRc': yRc, 'yLc': yLc}
        # store origins
        self.wheel0 = {'R': yRc - 0.0, 'L': yLc - 0.0}
        self.rail0 = {'R': yRc, 'L': yLc}
        self.zw0 = {'R': self.wheelR_nom.z(yRc), 'L': self.wheelL_nom.z(yLc)}
        self.zr0 = {'R': self.railR.z(yRc), 'L': self.railL.z(yLc)}
        # nominal contact angle and half-spacing
        self.delta0 = np.arctan(self.railR.dz(yRc))
        self.l = abs(yRc)                     # contact half-spacing [mm]


if __name__ == "__main__":
    wr = WheelRail()
    print("central uz=%.4f mm  phi=%.3e rad" % (wr.central['uz'], wr.central['phi']))
    print("right contact y = %.3f mm   left = %.3f mm" %
          (wr.central['yRc'], wr.central['yLc']))
    print("delta0 = %.4f deg   half-spacing l = %.2f mm  r0 = %.1f mm" %
          (np.degrees(wr.delta0), wr.l, wr.r0))
    d = wr.solve(0.0)
    print("check u_y=0:", {k: round(float(v), 5) for k, v in d.items()
                           if k in ('phi', 'uz', 'eta_wr', 'eta_rr', 'r_r', 'r_l')})
    for uy in (-8, -4, 0, 4, 8):
        d = wr.solve(uy)
        print("uy=%+5.1f  phi=%+.4e  uz=%+.4f  r_r=%.3f  r_l=%.3f  dR=%.4f  ddel=%.4f"
              % (uy, d['phi'], d['uz'], d['r_r'], d['r_l'],
                 d['r_r'] - d['r_l'], np.degrees(d['delta_r'] - d['delta_l'])))
