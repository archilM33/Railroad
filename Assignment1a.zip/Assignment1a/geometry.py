"""
geometry.py
Construct tangent-continuous rail (UIC60 / 60E1 head) and Indian-Standard
wheel (1-in-20 tread + flange) cross-section profiles from the appendix
drawing dimensions.

All lengths in millimetres.  Track frame:  y = lateral (+ to the right),
z = vertical (+ up).  Profiles are returned as dense (y, z) point arrays.
"""

import numpy as np


def _walk(x0, z0, theta0, segments, ds=0.02):
    """
    Integrate a plane curve of prescribed piecewise curvature (Frenet march).
    theta = tangent angle measured from +x axis.  Curvature kappa turns the
    tangent:  dtheta/ds = kappa.  Segments = list of (kappa, arclength).
    Guarantees tangent (slope) continuity across segments automatically.
    Returns arrays x, z.
    """
    xs, zs = [x0], [z0]
    x, z, th = x0, z0, theta0
    for kappa, L in segments:
        n = max(1, int(round(L / ds)))
        step = L / n
        for _ in range(n):
            th += kappa * step
            x += np.cos(th) * step
            z += np.sin(th) * step
            xs.append(x)
            zs.append(z)
    return np.array(xs), np.array(zs), th


# --------------------------------------------------------------------------
#  RAIL  :  UIC60 / 60E1 head  (crown R300 -> shoulder R80 -> corner R13)
# --------------------------------------------------------------------------
def build_rail(cant=1.0 / 20.0, y_center=0.0):
    """
    Symmetric rail head crown built outward from the crown apex.
    Central running band R=300, shoulder R=80, gauge/field corner R=13
    (60E1 head, EN 13674-1 nominal radii).  The head is then inclined by
    the installation cant (1:20 for Indian Railways).
    Returns y, z arrays (crown apex placed near origin, then shifted by y_center).
    """
    # march from apex outward to +x (right half); curvature switches by x-reach
    # choose arc extents so half-head width ~ 36 mm (72 mm head)
    # central R300 running band, R80 shoulders, R13 corners.  Field side is
    # extended so the de-flanging contact never runs off the modelled surface.
    seg_R300 = (-1.0 / 300.0, 26.0)     # negative kappa -> crown bends downward
    seg_R80 = (-1.0 / 80.0, 11.0)
    seg_R13 = (-1.0 / 13.0, 9.0)
    xr, zr, _ = _walk(0.0, 0.0, 0.0, [seg_R300, seg_R80, seg_R13], ds=0.02)
    xl, zl = -xr[::-1], zr[::-1]         # mirror
    x = np.concatenate([xl, xr[1:]])
    z = np.concatenate([zl, zr[1:]])
    # apply cant (rotate head inward by atan(cant)); rotation about apex
    a = -np.arctan(cant)          # negative -> tilt so gauge corner drops on -x side
    ca, sa = np.cos(a), np.sin(a)
    xr2 = ca * x - sa * z
    zr2 = sa * x + ca * z
    return xr2 + y_center, zr2


# --------------------------------------------------------------------------
#  WHEEL :  Indian Standard tread (1 in 20) + flange (throat, face, tip)
# --------------------------------------------------------------------------
def build_wheel(y_center=0.0, R_tread=450.0,
                t_band=(-16.0, 22.0), t_throat=9.0, t_field=45.0):
    """
    Right-wheel running profile, defined from an explicit slope law so that the
    nominal contact angle is exactly the 1-in-20 tread angle and the effective
    conicity / flange-onset are controlled independently.

    Local lateral t (+ toward field/outer), height h (+ up), nominal taping
    point at t=0.  Regions (field -> flange):
      field cone (straight, tangent to band)  |  curved running band (R_tread,
      slope = 1/20 at t=0)  |  throat fillet  |  1-in-2.5 flange face  |  tip.
    Flange (t<0) projects downward.  A straight cone gives R_w -> inf (the
    conical-wheel special case); the band curvature makes the contact migrate.

    The running band is made wide (t2 ~ -14 mm on the flange side) so that a
    fresh tread keeps single-point contact with a realistic flangeway clearance
    (~9 mm); the throat/flange only engages at large lateral shift, which stops
    the throat from stealing the contact within the working range.
    """
    s0 = 1.0 / 20.0                     # nominal tread slope (dh/dt at t=0)
    s_face = 2.5                        # flange-face slope magnitude (1 in 2.5)
    t2, t1 = t_band                     # band spans [t2, t1] about the taping pt
    t3 = t2 - t_throat                  # throat inner edge
    t4 = t3 - 7.0                       # flange face inner edge (~28-30 mm high)

    # slope grows toward the flange (-t) -> positive conicity, radius up on flange
    s_band_lo = s0 - t2 / R_tread       # band slope at inner (throat) edge (t2<0)
    s_band_hi = s0 - t1 / R_tread       # band slope at field edge

    def slope(t):
        t = np.asarray(t, float)
        s = np.empty_like(t)
        # field cone (tangent to band at t1)
        s[t >= t1] = s_band_hi
        # curved running band
        m = (t < t1) & (t >= t2)
        s[m] = s0 - t[m] / R_tread
        # throat fillet: steepen from band slope to flange-face slope
        m = (t < t2) & (t >= t3)
        s[m] = s_band_lo + (s_face - s_band_lo) * (t2 - t[m]) / (t2 - t3)
        # flange face (steep, straight)
        s[t < t3] = s_face
        return s

    t = np.linspace(t_field, t4, 8000)          # field -> flange
    sl = slope(t)
    # h(t) by integrating slope; h(0)=0
    h = np.concatenate([[0.0], np.cumsum(0.5 * (sl[1:] + sl[:-1]) * np.diff(t))])
    h = h - np.interp(0.0, t[::-1], h[::-1])     # set h(0)=0 (t descending)

    order = np.argsort(t)
    ts, hs = t[order], h[order]
    y = ts + y_center
    return y, hs


if __name__ == "__main__":
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    yr, zr = build_rail(y_center=0.0)
    yw, zw = build_wheel(y_center=0.0)

    fig, ax = plt.subplots(1, 2, figsize=(12, 4))
    ax[0].plot(yr, zr, "k"); ax[0].set_title("Rail head (60E1)")
    ax[0].set_aspect("equal"); ax[0].grid(True, ls=":")
    ax[1].plot(yw, zw, "r"); ax[1].set_title("Wheel profile (IRS 1:20 + flange)")
    ax[1].set_aspect("equal"); ax[1].grid(True, ls=":")
    fig.tight_layout(); fig.savefig("_profiles_check.png", dpi=110)
    print("rail  y range", yr.min(), yr.max(), " z range", zr.min(), zr.max())
    print("wheel y range", yw.min(), yw.max(), " z range", zw.min(), zw.max())
