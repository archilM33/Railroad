"""
approx.py  --  Assignment 1(b): Kinematics of a Railway Wheelset,
               APPROXIMATE (linearised) solution.

Starts from the exact contact geometry produced by Assignment 1(a)
(solver.py / geometry.py), evaluates the central-position quantities
delta0, R_w, R_r, and then applies the small-displacement formulae:

    r_r , r_l    = r0 +/- lambda0 * u_y                         (29)
    d_rr, d_rl   = delta0 +/- eps0  * u_y / l                    (22)
    d_wr, d_wl   = delta0 +/- eps0* * u_y / l                    (24)

    phi_y = d(phi)/du_y = -sigma      / [ l (1 - r0 delta0 / l) ] (16)
    z_y   = d(u_z)/du_y = -eps * u_y  / [ l (1 - r0 delta0 / l) ] (17)

with
    sigma  = delta0                                              (18)
    eps    = (d_rr - d_rl) * l / (2 u_y)                         (19)
    eps0   = l (1 + R_w delta0/l) / [(R_w - R_r)(1 - r0 delta0/l)]  (23)
    eps0*  = l (1 + R_r delta0/l) / [(R_w - R_r)(1 - r0 delta0/l)]  (25)
    lambda0= delta0 R_w (1 + R_r delta0/l)
                         / [(R_w - R_r)(1 - r0 delta0/l)]        (30)

and the radius-of-curvature formula
    R = [1 + (dzeta/deta)^2]^(3/2) / |d2zeta/deta2|

eps0, eps0* and lambda0 are evaluated in the central undisturbed position.

SIGN CONVENTION.  The lecture frame has Oz pointing DOWN, so a wheelset that
rises as it moves sideways has u_z < 0 (this is why the lecture's u_z plot is
a downward parabola).  Assignment 1(a) here was solved with z positive UP.
Everything below is reported in the LECTURE convention; the exact 1(a) values
are sign-flipped where they are compared.
"""
import numpy as np
from solver import WheelRail

# ------------------------------------------------------------------ parameters
# Values prescribed by Assignment 1(b):
R0_ASSIGN, Y0_ASSIGN, L_ASSIGN = 500.0, 0.0, 1100.0


class Approx:
    """Small-displacement (linearised) solution of the wheelset kinematics."""

    def __init__(self, wr=None, r0=R0_ASSIGN, y0=Y0_ASSIGN, l=L_ASSIGN):
        """
        wr : a solved WheelRail object from Assignment 1(a).  Supplies the
             profile geometry, i.e. delta0, R_w and R_r at the central point.
        r0, y0, l : the wheelset/track constants to use in the formulae.
        """
        self.wr = wr if wr is not None else WheelRail()
        self.r0, self.y0, self.l = float(r0), float(y0), float(l)

        # --- central (undisturbed) geometry, from the exact 1(a) solution ---
        c = self.wr.solve(0.0)
        self.delta0 = float(c['delta_r'])        # nominal contact angle [rad]
        self.Rw0 = float(c['Rw_r'])              # wheel-tread curvature radius
        self.Rr0 = float(c['Rr_r'])              # rail-head curvature radius

        d0, l_, r0_ = self.delta0, self.l, self.r0
        Rw, Rr = self.Rw0, self.Rr0
        den = (Rw - Rr) * (1.0 - r0_ * d0 / l_)

        self.sigma = d0                                            # (18)
        self.eps0 = l_ * (1.0 + Rw * d0 / l_) / den                # (23)
        self.eps0_star = l_ * (1.0 + Rr * d0 / l_) / den           # (25)
        self.lambda0 = d0 * Rw * (1.0 + Rr * d0 / l_) / den        # (30)

        # common denominator of (16) and (17)
        self.denom = l_ * (1.0 - r0_ * d0 / l_)

        # phi_y is a constant in the linearised theory
        self.phi_y = -self.sigma / self.denom                      # (16)

    # ------------------------------------------------------------------
    def solve(self, uy):
        """Approximate solution at lateral displacement u_y (mm)."""
        uy = np.atleast_1d(np.asarray(uy, float))
        d0, l_, r0_ = self.delta0, self.l, self.r0

        # rolling radii (29)
        r_r = r0_ + self.lambda0 * uy
        r_l = r0_ - self.lambda0 * uy

        # rail contact angles (22)  and  wheel contact angles (24)
        d_rr = d0 + self.eps0 * uy / l_
        d_rl = d0 - self.eps0 * uy / l_
        d_wr = d0 + self.eps0_star * uy / l_
        d_wl = d0 - self.eps0_star * uy / l_

        # eps from its definition (19); identically eps0 in the linear theory
        with np.errstate(divide='ignore', invalid='ignore'):
            eps = np.where(uy != 0.0, (d_rr - d_rl) * l_ / (2.0 * uy), self.eps0)

        # derivatives (16), (17)
        phi_y = np.full_like(uy, self.phi_y)
        z_y = -eps * uy / self.denom

        # integrated roll and vertical displacement (lecture sign convention)
        phi = self.phi_y * uy                       # phi_y constant  -> linear
        u_z = -0.5 * self.eps0 * uy ** 2 / self.denom
        # alternative closed form, eqn (34)
        u_z34 = -(self.Rw0 - self.Rr0) * self.eps0 ** 2 * uy ** 2 / (2.0 * l_ ** 2)

        return dict(uy=uy, r_r=r_r, r_l=r_l, dr=r_r - r_l,
                    d_rr=d_rr, d_rl=d_rl, d_wr=d_wr, d_wl=d_wl,
                    ddelta=d_rr - d_rl, eps=eps,
                    phi_y=phi_y, z_y=z_y, phi=phi, u_z=u_z, u_z34=u_z34)

    # ------------------------------------------------------------------
    def exact(self, uys):
        """Exact 1(a) values on the same grid, in the LECTURE sign convention."""
        rows = [self.wr.solve(float(u)) for u in uys]
        g = lambda k: np.array([r.get(k, np.nan) for r in rows], float)
        uz0 = self.wr.solve(0.0)['uz']
        return dict(uy=np.asarray(uys, float),
                    r_r=g('r_r'), r_l=g('r_l'), dr=g('r_r') - g('r_l'),
                    d_rr=g('delta_r'), d_rl=g('delta_l'),
                    ddelta=g('delta_r') - g('delta_l'),
                    Rr_r=g('Rr_r'), Rr_l=g('Rr_l'),
                    Rw_r=g('Rw_r'), Rw_l=g('Rw_l'),
                    phi=g('phi'),
                    u_z=-(g('uz') - uz0))      # flip: 1(a) had z up, lecture z down

    # ------------------------------------------------------------------
    def report(self):
        deg = np.degrees
        return (
            f"  delta0 = {self.delta0:.6f} rad = {deg(self.delta0):.4f} deg"
            f"   (tan delta0 = {np.tan(self.delta0):.5f} ~ 1/20)\n"
            f"  R_w    = {self.Rw0:.2f} mm      R_r = {self.Rr0:.2f} mm"
            f"   (central position)\n"
            f"  r0 = {self.r0:.1f} mm   y0 = {self.y0:.1f} mm   l = {self.l:.1f} mm\n"
            f"  eps0     = {self.eps0:.4f}        (23)\n"
            f"  eps0*    = {self.eps0_star:.4f}        (25)\n"
            f"  lambda0  = {self.lambda0:.5f}       (30)  <- effective conicity\n"
            f"  sigma    = {self.sigma:.6f}       (18)\n"
            f"  phi_y    = {self.phi_y:.6e} rad/mm = {self.phi_y*1e3:.4f} rad/m  (16)\n"
            f"  z_y      = {-self.eps0/self.denom:.6e} * u_y   (17)\n")


if __name__ == "__main__":
    wr = WheelRail()
    print("=" * 68)
    print("ASSIGNMENT 1(b) -- approximate solution, prescribed constants")
    print("=" * 68)
    a = Approx(wr)
    print(a.report())

    print("=" * 68)
    print("Same profiles, but with the constants that match the 1(a) geometry")
    print("=" * 68)
    b = Approx(wr, r0=wr.r0, l=wr.l)
    print(b.report())

    uys = np.array([0, 2, 4, 6, 8], float)
    A, E = b.solve(uys), b.exact(uys)
    print(" u_y   r_r-r_l  (exact)   d_rr(deg) (exact)   phi(mr) (exact)"
          "   u_z(mm) (exact)")
    for i, u in enumerate(uys):
        print("%4.0f  %7.3f %8.3f   %7.3f %8.3f   %7.3f %8.3f   %7.4f %8.4f"
              % (u, A['dr'][i], E['dr'][i],
                 np.degrees(A['d_rr'][i]), np.degrees(E['d_rr'][i]),
                 A['phi'][i] * 1e3, E['phi'][i] * 1e3,
                 A['u_z'][i], E['u_z'][i]))
