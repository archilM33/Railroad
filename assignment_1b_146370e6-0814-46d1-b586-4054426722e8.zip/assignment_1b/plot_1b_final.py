"""
plot_1b.py  --  figures for Assignment 1(b) (approximate solution).

Produces
  fig1b_main.png        r, delta, R_r, R_w  vs u_y   (the layout asked for)
  fig1b_deltaw.png      wheel contact angles + the two differences
  fig1b_derivatives.png z_y and phi_y vs u_y
  fig1b_compare.png     approximate (1b) against exact (1a)
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from solver import WheelRail
from approx import Approx

plt.rcParams.update({
    "font.size": 10, "axes.grid": True, "grid.linestyle": ":",
    "grid.alpha": 0.6, "figure.dpi": 120, "axes.titlesize": 10,
    "lines.linewidth": 1.7,
})
CR, CL = "#c0392b", "#2471a3"          # right / left
CE = "#7f8c8d"                          # exact (reference) curves
OUT = "."
UMAX = 8.0


def fig_main(ap, A, E, u):
    """r, delta, R_r, R_w versus u_y -- the layout shown in the assignment."""
    fig, ax = plt.subplots(2, 2, figsize=(11, 8))

    ax[0, 0].plot(u, A['r_r'], color=CR, label="r  (right)")
    ax[0, 0].plot(u, A['r_l'], color=CL, label="l  (left)")
    ax[0, 0].set_ylabel("r  [mm]"); ax[0, 0].set_title(
        r"Rolling radius   $r_{r},r_{l}=r_0\pm\lambda_0 u_y$   (29)")

    ax[0, 1].plot(u, A['d_rr'], color=CR, label="r  (right)")
    ax[0, 1].plot(u, A['d_rl'], color=CL, label="l  (left)")
    ax[0, 1].set_ylabel(r"$\delta$  [rad]"); ax[0, 1].set_title(
        r"Rail contact angle   $\delta_{rr},\delta_{rl}=\delta_0\pm\varepsilon_0 u_y/l$   (22)")

    ax[1, 0].plot(u, E['Rr_r'], color=CR, label="r  (right)")
    ax[1, 0].plot(u, E['Rr_l'], color=CL, label="l  (left)")
    ax[1, 0].set_ylabel(r"$R_r$  [mm]"); ax[1, 0].set_title(
        "Rail-head curvature radius $R_r$  (from the $R$ formula)")

    Rwr = np.clip(E['Rw_r'], 0, 1200); Rwl = np.clip(E['Rw_l'], 0, 1200)
    ax[1, 1].plot(u, Rwr, color=CR, label="r  (right)")
    ax[1, 1].plot(u, Rwl, color=CL, label="l  (left)")
    ax[1, 1].set_ylabel(r"$R_w$  [mm]"); ax[1, 1].set_title(
        "Wheel-tread curvature radius $R_w$  (from the $R$ formula)")

    for a in ax.ravel():
        a.set_xlabel(r"$u_y$  [mm]"); a.axvline(0, color="k", lw=0.6, alpha=0.4)
        a.legend(fontsize=8, loc="best")
    fig.suptitle("Assignment 1(b) — approximate solution   "
                 fr"($r_0$={ap.r0:.0f} mm, $l$={ap.l:.0f} mm, "
                 fr"$\lambda_0$={ap.lambda0:.4f}, $\varepsilon_0$={ap.eps0:.3f})",
                 y=1.01, fontsize=12)
    fig.tight_layout(); fig.savefig(f"{OUT}/fig1b_main.png", bbox_inches="tight")
    plt.close(fig)


def fig_deltaw(ap, A, u):
    fig, ax = plt.subplots(1, 3, figsize=(13, 3.9))
    ax[0].plot(u, A['d_wr'], color=CR, label="r  (right)")
    ax[0].plot(u, A['d_wl'], color=CL, label="l  (left)")
    ax[0].set_ylabel(r"$\delta_w$  [rad]")
    ax[0].set_title(r"Wheel contact angle  $\delta_0\pm\varepsilon_0^{*}u_y/l$   (24)")

    ax[1].plot(u, A['dr'], color="#2c3e50")
    ax[1].set_ylabel(r"$r_r-r_l$  [mm]")
    ax[1].set_title(r"$r_r-r_l = 2\lambda_0 u_y$")

    ax[2].plot(u, A['ddelta'], color="#2c3e50")
    ax[2].set_ylabel(r"$\delta_{rr}-\delta_{rl}$  [rad]")
    ax[2].set_title(r"$\delta_{rr}-\delta_{rl} = 2\varepsilon_0 u_y/l$")

    for a in ax:
        a.set_xlabel(r"$u_y$  [mm]")
        a.axvline(0, color="k", lw=0.6, alpha=0.4)
        a.axhline(0, color="k", lw=0.6, alpha=0.4)
    ax[0].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(f"{OUT}/fig1b_deltaw.png", bbox_inches="tight")
    plt.close(fig)


def fig_derivs(ap, A, apg, Ag, E, u):
    """z_y and phi_y: prescribed constants, geometry-consistent, and exact."""
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.4))
    lab_p = fr"approx, prescribed $l$={ap.l:.0f} mm"
    lab_g = fr"approx, geometry $l$={apg.l:.0f} mm"

    ax[0].plot(u, np.gradient(E['u_z'], u), color=CE, lw=2.4, label="exact 1(a)")
    ax[0].plot(u, A['z_y'], "--", color="#e67e22", label=lab_p)
    ax[0].plot(u, Ag['z_y'], ":", color="#8e44ad", label=lab_g)
    ax[0].set_ylabel(r"$z_y=du_z/du_y$  [-]")
    ax[0].set_title(r"$z_y=-\varepsilon u_y/l(1-r_0\delta_0/l)$   (17)")

    ax[1].plot(u, np.gradient(E['phi'], u) * 1e3, color=CE, lw=2.4, label="exact 1(a)")
    ax[1].plot(u, A['phi_y'] * 1e3, "--", color="#e67e22", label=lab_p)
    ax[1].plot(u, Ag['phi_y'] * 1e3, ":", color="#8e44ad", label=lab_g)
    ax[1].set_ylabel(r"$\phi_y=d\phi/du_y$  [rad/m]")
    ax[1].set_title(r"$\phi_y=-\sigma/l(1-r_0\delta_0/l)$   (16)")
    ax[1].set_ylim(1.6 * apg.phi_y * 1e3, 0)

    for a in ax:
        a.set_xlabel(r"$u_y$  [mm]")
        a.axvline(0, color="k", lw=0.6, alpha=0.4)
        a.axhline(0, color="k", lw=0.6, alpha=0.4)
        a.legend(fontsize=8, loc="best")
    fig.suptitle("Rate of change of vertical displacement and roll with lateral "
                 "displacement", y=1.02, fontsize=11)
    fig.tight_layout(); fig.savefig(f"{OUT}/fig1b_derivatives.png", bbox_inches="tight")
    plt.close(fig)


def fig_compare(ap, A, E, u):
    fig, ax = plt.subplots(2, 2, figsize=(11, 7.6))

    ax[0, 0].plot(u, E['dr'], color=CE, lw=2.4, label="exact  1(a)")
    ax[0, 0].plot(u, A['dr'], "--", color=CR, label="approx  1(b)")
    ax[0, 0].set_ylabel(r"$r_r-r_l$  [mm]"); ax[0, 0].set_title("Rolling-radius difference")

    ax[0, 1].plot(u, E['d_rr'], color=CE, lw=2.4, label=r"exact $\delta_{rr}$")
    ax[0, 1].plot(u, A['d_rr'], "--", color=CR, label=r"approx $\delta_{rr}$")
    ax[0, 1].plot(u, E['d_rl'], color=CE, lw=2.4, alpha=0.55, label=r"exact $\delta_{rl}$")
    ax[0, 1].plot(u, A['d_rl'], "--", color=CL, label=r"approx $\delta_{rl}$")
    ax[0, 1].set_ylabel(r"$\delta$  [rad]"); ax[0, 1].set_title("Rail contact angles")

    ax[1, 0].plot(u, E['phi'] * 1e3, color=CE, lw=2.4, label="exact  1(a)")
    ax[1, 0].plot(u, A['phi'] * 1e3, "--", color="#16a085", label="approx  1(b)")
    ax[1, 0].set_ylabel(r"$\phi$  [mrad]"); ax[1, 0].set_title("Roll angle")

    ax[1, 1].plot(u, E['u_z'], color=CE, lw=2.4, label="exact  1(a)")
    ax[1, 1].plot(u, A['u_z'], "--", color="#e67e22", label="approx  1(b)")
    ax[1, 1].set_ylabel(r"$u_z$  [mm]"); ax[1, 1].set_title(
        r"Vertical displacement  ($Oz$ down: $u_z<0$ = wheelset rises)")

    for a in ax.ravel():
        a.set_xlabel(r"$u_y$  [mm]"); a.axvline(0, color="k", lw=0.6, alpha=0.4)
        a.legend(fontsize=8, loc="best")
    fig.suptitle("Approximate solution 1(b) checked against the exact solution 1(a)",
                 y=1.01, fontsize=12)
    fig.tight_layout(); fig.savefig(f"{OUT}/fig1b_compare.png", bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    wr = WheelRail()
    u = np.linspace(-UMAX, UMAX, 161)

    # --- the assignment's prescribed constants: main deliverable ---
    ap = Approx(wr)
    A = ap.solve(u)
    E = ap.exact(u)                      # exact curvatures for the R panels
    fig_main(ap, A, E, u)
    fig_deltaw(ap, A, u)

    # --- geometry-consistent constants: honest accuracy check vs 1(a) ---
    apg = Approx(wr, r0=wr.r0, l=wr.l)
    fig_derivs(ap, A, apg, apg.solve(u), E, u)
    fig_compare(apg, apg.solve(u), apg.exact(u), u)

    print(ap.report())
    print("max |approx - exact| over |u_y|<=8 mm, geometry-consistent constants:")
    Ag, Eg = apg.solve(u), apg.exact(u)
    for k, lab, sc in (('dr', 'r_r-r_l  [mm]', 1), ('d_rr', 'delta_rr [mrad]', 1e3),
                       ('phi', 'phi      [mrad]', 1e3), ('u_z', 'u_z      [mm]', 1)):
        print("   %-18s %.4f" % (lab, np.nanmax(np.abs(Ag[k] - Eg[k])) * sc))
    print("figures written.")
